# Infrastructure
Docker Compose runs frontend, API, Celery worker, PostgreSQL and Redis for local development. Production deployment should use managed database/Redis, TLS, secret manager, separate worker autoscaling and a proper Supabase JWT verification layer.
