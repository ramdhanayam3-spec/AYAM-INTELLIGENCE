-- Supabase Auth owns credentials. Profiles reference auth.users; no password_hash column.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role text not null default 'member' check (role in ('owner','admin','analyst','member')),
  created_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan_type text not null default 'free',
  usage_limits jsonb not null default '{}'::jsonb,
  billing_status text not null default 'inactive',
  created_at timestamptz not null default now()
);

create table if not exists public.research_tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  task_type text not null,
  status text not null default 'pending' check (status in ('pending','processing','completed','failed')),
  request_payload jsonb not null default '{}'::jsonb,
  result_payload jsonb,
  error_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  normalized_key text not null,
  name text not null,
  category text,
  marketplace text not null,
  base_price numeric(14,2),
  currency char(3),
  source_name text,
  source_url text,
  source_updated_at timestamptz,
  confidence numeric(5,2),
  created_at timestamptz not null default now(),
  unique(normalized_key, marketplace)
);

create table if not exists public.product_scores (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  demand_score numeric(5,2),
  profit_score numeric(5,2),
  competition_score numeric(5,2),
  keyword_score numeric(5,2),
  growth_score numeric(5,2),
  total_score numeric(5,2),
  weights jsonb not null,
  calculated_at timestamptz not null default now()
);

create table if not exists public.competitors (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  domain text not null,
  label text,
  tracked_since timestamptz not null default now(),
  unique(user_id, domain)
);

create table if not exists public.keyword_metrics (
  id uuid primary key default gen_random_uuid(),
  keyword text not null,
  country char(2) not null,
  marketplace text,
  source_name text not null,
  metric_date date not null,
  search_volume bigint,
  cpc numeric(14,4),
  difficulty numeric(5,2),
  intent text,
  raw_payload jsonb not null default '{}'::jsonb,
  unique(keyword,country,marketplace,source_name,metric_date)
);

create table if not exists public.historical_metrics (
  id uuid primary key default gen_random_uuid(),
  entity_type text not null,
  entity_key text not null,
  metric_name text not null,
  market_code text not null,
  source_name text not null,
  metric_date date not null,
  metric_value numeric(20,4),
  currency char(3),
  raw_payload jsonb not null default '{}'::jsonb,
  unique(entity_type,entity_key,metric_name,market_code,source_name,metric_date)
);

create index if not exists idx_tasks_user_created on public.research_tasks(user_id,created_at desc);
create index if not exists idx_history_entity_date on public.historical_metrics(entity_type,entity_key,metric_date desc);
create index if not exists idx_keywords_country_date on public.keyword_metrics(country,metric_date desc);

alter table public.profiles enable row level security;
alter table public.subscriptions enable row level security;
alter table public.research_tasks enable row level security;
alter table public.competitors enable row level security;

create policy "profile self read" on public.profiles for select using (auth.uid() = id);
create policy "profile self update" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);
create policy "subscription self read" on public.subscriptions for select using (auth.uid() = user_id);
create policy "task self access" on public.research_tasks for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "competitor self access" on public.competitors for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Historical table policies should be added once tenant ownership is modelled for each entity.
