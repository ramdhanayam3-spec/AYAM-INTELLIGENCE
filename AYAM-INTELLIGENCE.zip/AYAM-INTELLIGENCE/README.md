# AYAM INTELLIGENCE

Enterprise-ready starter monorepo for worldwide e-commerce product, keyword, competitor and growth intelligence.

## Monorepo layout
- `frontend/` — Next.js App Router + TypeScript dashboard
- `backend/` — FastAPI API, business services, schemas and research adapters
- `ai-workflows/` — Master agent and specialist agent contracts
- `database/` — Supabase/PostgreSQL migrations and seed data
- `infra/` — Docker Compose and GitHub Actions
- `docs/` — PRD, TRD, API and architecture documentation

## Quick start
1. Copy `.env.example` to `.env` and configure Supabase, Redis and provider API keys.
2. Run `docker compose up --build`.
3. Frontend: http://localhost:3000
4. API docs: http://localhost:8000/docs

The dashboard uses clearly-labelled sample data until live provider credentials and adapters are configured. No estimates are represented as verified marketplace sales.

## Security notes
Supabase Auth owns authentication and password storage. The app stores only the Supabase user UUID and profile metadata. Never store plaintext passwords or locally managed password hashes in `public.users`.
