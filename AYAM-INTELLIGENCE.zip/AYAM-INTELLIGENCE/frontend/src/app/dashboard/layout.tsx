import { Sidebar } from "@/components/layout/sidebar";
import { Topbar } from "@/components/layout/topbar";
export default function DashboardLayout({children}:{children:React.ReactNode}) { return <div className="min-h-screen"><Sidebar/><main className="min-h-screen pl-[250px] max-md:pl-0"><Topbar/><div className="px-8 py-7 max-md:px-4">{children}</div></main></div>; }
