import type { Config } from "tailwindcss";
const config: Config = { content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"], theme: { extend: { colors: { ink: "#101828", brand: "#635BFF", mint: "#12B886" }, boxShadow: { soft: "0 8px 30px rgba(16,24,40,.06)" } } }, plugins: [] };
export default config;
