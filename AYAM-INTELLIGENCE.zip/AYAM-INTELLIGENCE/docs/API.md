# API outline

Base URL: `/api/v1`

- `GET /health` — liveness.
- `POST /products/research` — accept a research brief; returns `202` with task ID.
- `POST /scoring/preview` — weighted score preview.
- `POST /profit-calculator` — net profit, margin, ROI and break-even ROAS.
- Planned: `GET /tasks/{task_id}`, `GET /products`, `GET /keywords`, `POST /competitors/analyze`, `GET /analytics/history`.

All protected endpoints require a validated Supabase bearer token. Pagination uses cursor or bounded limit/offset; inputs and outputs are Pydantic schemas. Implement request-scoped ownership checks before exposing persisted results.
