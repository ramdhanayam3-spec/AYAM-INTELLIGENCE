# Technical Requirements — AYAM INTELLIGENCE

## Stack
Frontend Next.js App Router, TypeScript, Tailwind, shadcn/ui-ready component structure, Lucide, Framer Motion, React Query, Zustand, Zod and Apache ECharts.
Backend Python 3.11+, FastAPI, Pydantic, SQLAlchemy async, Celery and Redis.
ML: PyTorch/Hugging Face are optional model workers, not required for basic scoring.
Data: Supabase PostgreSQL/Auth/Storage; RLS for tenant isolation.
Ops: Docker Compose, GitHub Actions, pytest and Playwright.

## Boundaries
The browser never receives service-role keys. API authenticates Supabase JWTs and derives user identity from the verified token. Provider keys remain server-side. Every external metric carries provider, query scope, date window, currency, fetched_at and provenance.

## Data retention
72 months is a product retention goal, not a promise of 72 months of source history. Persist only data permitted by provider contract and supported by source coverage.

## Asynchronous execution
POST request -> persist research task -> enqueue Celery task -> orchestrate specialist agents -> validate and normalize provider responses -> score -> report -> store result -> notify/poll frontend.

## Resilience
Idempotency keys, request timeouts, bounded retries with jitter, per-provider circuit breaker, job dead-letter handling, structured logs and request IDs.
