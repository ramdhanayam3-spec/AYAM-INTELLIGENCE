# Product Requirements — AYAM INTELLIGENCE

## Vision
One global workspace for e-commerce opportunity research, keyword intelligence, competitor benchmarking and growth analysis.

## Personas
- Solo sellers validating product ideas
- E-commerce operators managing several marketplaces
- Analysts and agencies preparing market reports

## Core modules
1. Product Research: category, marketplace, geography, price and opportunity filters.
2. Keyword Intelligence: search demand, CPC where available, intent, difficulty and historical trends.
3. Competitor Intelligence: domain comparisons, keyword overlap, product and price positioning.
4. Growth Analytics: source-attributed time series; target up to 72 months where a provider's license and actual coverage allow.
5. AI Research Workspace: Master agent delegates to product, keyword, competitor and growth agents, followed by scoring and report synthesis.
6. Profit Calculator: product cost, shipping, marketplace fees, ad cost, other costs, net profit, margin, ROI and break-even ROAS.
7. Workspace & Billing: Supabase Auth, tenant isolation, RBAC, plan entitlements and usage controls.

## Opportunity score
Default weights: Demand 25%, Profit 25%, Competition 20%, Keywords 15%, Growth 15%. Every input is normalized 0–100. Competition score is defined as *ease* (higher = lower competitive pressure). The weights must sum to 100%; expose versioned configurable weights.

## Non-functional requirements
- Provider provenance, freshness timestamps, geography and currency on all metrics.
- Asynchronous jobs with status and retry policy.
- Per-user and per-plan rate/usage limits.
- No scraped source integration without permission/terms review.
- Explicit distinction between observed, estimated, modelled and sample values.
- Audit logs for admin actions and exports.
