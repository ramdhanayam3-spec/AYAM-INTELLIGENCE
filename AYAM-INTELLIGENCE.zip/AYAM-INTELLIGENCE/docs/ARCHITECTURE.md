# Architecture

```mermaid
flowchart LR
  UI[Next.js Dashboard] --> API[FastAPI API]
  API --> AUTH[Supabase Auth]
  API --> DB[(PostgreSQL)]
  API --> Q[Redis Queue]
  Q --> MASTER[Master Agent]
  MASTER --> PA[Product Agent]
  MASTER --> KA[Keyword Agent]
  MASTER --> CA[Competitor Agent]
  MASTER --> GA[Growth Agent]
  PA --> PROVIDERS[Licensed Data Providers]
  KA --> PROVIDERS
  CA --> PROVIDERS
  GA --> DB
  MASTER --> SCORE[Scoring Agent]
  SCORE --> REPORT[Report Agent]
  REPORT --> DB
  DB --> UI
```

All agents are orchestration components, not sources of truth. External data provider adapters are responsible for provenance and coverage declarations. Similarweb is an optional web traffic/keyword intelligence integration and should not be represented as a universal marketplace product-sales feed.
