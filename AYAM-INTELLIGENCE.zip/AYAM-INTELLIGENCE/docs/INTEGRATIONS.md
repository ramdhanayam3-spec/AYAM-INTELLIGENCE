# Integrations

## Similarweb
Use the Similarweb APIs available under the subscribed plan for web traffic, engagement, keyword visibility, referrals and related benchmarking. The included adapter is deliberately thin and must be matched to the exact current API contract/version and plan entitlement before production. Some connector endpoints exposed in ChatGPT are not necessarily equivalent to a direct API endpoint available under the same commercial plan. Never expose the API key to the browser.

## Marketplace product intelligence
Use authorized marketplace APIs, affiliate/product feeds or contracted data providers for product-level price, rank, units sold and revenue estimates. Similarweb traffic estimates must not be converted into marketplace unit-sales estimates without a disclosed and validated model.

## Supabase
Enable Auth providers, configure redirect URLs, apply SQL migrations, review RLS, use service role only on trusted server workloads, and test tenant boundaries.
