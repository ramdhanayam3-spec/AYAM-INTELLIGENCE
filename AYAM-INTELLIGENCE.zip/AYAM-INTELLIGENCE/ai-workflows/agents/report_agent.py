from .base import ResearchAgent
class ReportAgent(ResearchAgent):
    name = "report"
    async def run(self, context: dict) -> dict:
        return {"agent": self.name, "status": "ready_to_compile", "sections": []}
