from .base import ResearchAgent
class ProductAgent(ResearchAgent):
    name = "product"
    async def run(self, context: dict) -> dict:
        return {"agent": self.name, "status": "awaiting_provider_data", "query": context.get("query")}
