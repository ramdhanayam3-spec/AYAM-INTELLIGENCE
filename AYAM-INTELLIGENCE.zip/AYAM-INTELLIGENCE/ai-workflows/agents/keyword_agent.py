from .base import ResearchAgent
class KeywordAgent(ResearchAgent):
    name = "keyword"
    async def run(self, context: dict) -> dict:
        return {"agent": self.name, "status": "awaiting_provider_data", "seed": context.get("query")}
