from .base import ResearchAgent
class GrowthAgent(ResearchAgent):
    name = "growth"
    async def run(self, context: dict) -> dict:
        return {"agent": self.name, "status": "awaiting_historical_data"}
