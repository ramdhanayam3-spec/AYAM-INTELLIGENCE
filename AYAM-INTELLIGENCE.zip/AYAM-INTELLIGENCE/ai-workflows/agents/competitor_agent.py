from .base import ResearchAgent
class CompetitorAgent(ResearchAgent):
    name = "competitor"
    async def run(self, context: dict) -> dict:
        return {"agent": self.name, "status": "awaiting_provider_data", "domain": context.get("domain")}
