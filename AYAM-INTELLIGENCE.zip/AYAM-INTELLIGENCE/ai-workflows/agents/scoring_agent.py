from .base import ResearchAgent
class ScoringAgent(ResearchAgent):
    name = "scoring"
    async def run(self, context: dict) -> dict:
        return {"agent": self.name, "status": "ready", "scoring_version": "weighted-v1"}
