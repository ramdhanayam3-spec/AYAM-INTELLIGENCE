from abc import ABC, abstractmethod
from typing import Any

class ResearchAgent(ABC):
    name = "base"
    @abstractmethod
    async def run(self, context: dict[str, Any]) -> dict[str, Any]:
        raise NotImplementedError
