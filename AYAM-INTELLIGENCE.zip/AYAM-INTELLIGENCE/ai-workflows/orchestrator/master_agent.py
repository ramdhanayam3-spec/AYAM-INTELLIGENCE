"""Master agent contract. Execute specialists concurrently after provider + policy checks."""
import asyncio
from agents.product_agent import ProductAgent
from agents.keyword_agent import KeywordAgent
from agents.competitor_agent import CompetitorAgent
from agents.growth_agent import GrowthAgent
from agents.scoring_agent import ScoringAgent
from agents.report_agent import ReportAgent

async def run_research(context: dict) -> dict:
    agents = [ProductAgent(), KeywordAgent(), CompetitorAgent(), GrowthAgent()]
    results = await asyncio.gather(*(agent.run(context) for agent in agents))
    scoring = await ScoringAgent().run({"agent_results": results})
    report = await ReportAgent().run({"agent_results": results, "scoring": scoring})
    return {"orchestrator": "master", "agent_results": results, "scoring": scoring, "report": report}
