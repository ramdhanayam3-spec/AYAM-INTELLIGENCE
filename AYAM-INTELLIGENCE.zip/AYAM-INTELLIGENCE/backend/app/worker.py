from celery import Celery
from app.core.config import settings
celery_app = Celery("ayam_intelligence", broker=settings.redis_url, backend=settings.redis_url)
celery_app.conf.task_routes = {"app.worker.run_research": {"queue": "research"}}

@celery_app.task(name="app.worker.run_research")
def run_research(task_id: str, payload: dict) -> dict:
    # Orchestration entrypoint: wire agents and licensed data providers here.
    return {"task_id": task_id, "status": "queued_for_provider_configuration"}
