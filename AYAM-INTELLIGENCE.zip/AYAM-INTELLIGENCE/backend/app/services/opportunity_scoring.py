from dataclasses import dataclass

@dataclass(frozen=True)
class OpportunityWeights:
    demand: float = 0.25
    profit: float = 0.25
    competition: float = 0.20
    keywords: float = 0.15
    growth: float = 0.15

    def validate(self) -> None:
        total = self.demand + self.profit + self.competition + self.keywords + self.growth
        if abs(total - 1.0) > 1e-8:
            raise ValueError("Opportunity weights must sum to 1.0")

def score_opportunity(*, demand: float, profit: float, competition: float,
                       keywords: float, growth: float,
                       weights: OpportunityWeights = OpportunityWeights()) -> float:
    """Each input is normalized to 0..100; high competition input means easier/less crowded."""
    weights.validate()
    values = (demand, profit, competition, keywords, growth)
    if any(v < 0 or v > 100 for v in values):
        raise ValueError("All component scores must be between 0 and 100")
    return round(
        demand * weights.demand + profit * weights.profit +
        competition * weights.competition + keywords * weights.keywords +
        growth * weights.growth, 2
    )
