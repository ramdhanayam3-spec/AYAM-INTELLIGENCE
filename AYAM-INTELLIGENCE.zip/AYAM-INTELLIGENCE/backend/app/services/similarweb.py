"""Thin Similarweb adapter. Credentials and plan entitlements are required for live calls."""
import httpx
from app.core.config import settings

class SimilarwebClient:
    BASE_URL = "https://api.similarweb.com"

    def __init__(self) -> None:
        if not settings.similarweb_api_key:
            raise RuntimeError("SIMILARWEB_API_KEY is not configured")

    async def website_traffic(self, domain: str, country: str = "ww") -> dict:
        # Confirm current endpoint version/contract in the Similarweb account before production use.
        url = f"{self.BASE_URL}/v1/website/{domain}/total-traffic-and-engagement/visits"
        params = {"api_key": settings.similarweb_api_key, "country": country}
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(url, params=params)
            response.raise_for_status()
            return response.json()
