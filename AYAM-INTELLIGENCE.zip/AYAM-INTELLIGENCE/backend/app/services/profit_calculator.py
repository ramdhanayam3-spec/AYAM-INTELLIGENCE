from pydantic import BaseModel, Field

class ProfitInput(BaseModel):
    selling_price: float = Field(gt=0)
    product_cost: float = Field(ge=0)
    shipping_cost: float = Field(ge=0, default=0)
    marketplace_fee_pct: float = Field(ge=0, le=100, default=15)
    ad_cost_per_order: float = Field(ge=0, default=0)
    other_costs: float = Field(ge=0, default=0)

def calculate_profit(data: ProfitInput) -> dict:
    fees = data.selling_price * data.marketplace_fee_pct / 100
    net = data.selling_price - data.product_cost - data.shipping_cost - fees - data.ad_cost_per_order - data.other_costs
    invested = data.product_cost + data.shipping_cost + fees + data.ad_cost_per_order + data.other_costs
    margin_pct = net / data.selling_price * 100
    roi_pct = net / invested * 100 if invested else 0
    # Break-even ROAS uses ad spend as denominator and contribution before ads as numerator.
    contribution_before_ads = data.selling_price - data.product_cost - data.shipping_cost - fees - data.other_costs
    break_even_roas = data.selling_price / contribution_before_ads if contribution_before_ads > 0 else None
    return {"marketplace_fees": round(fees, 2), "net_profit": round(net, 2),
            "profit_margin_pct": round(margin_pct, 2), "roi_pct": round(roi_pct, 2),
            "break_even_roas": round(break_even_roas, 2) if break_even_roas else None}
