from pydantic import BaseModel, Field
from typing import Literal

class ProductResearchRequest(BaseModel):
    query: str = Field(min_length=2, max_length=200)
    marketplace: Literal["amazon.com", "amazon.co.uk", "amazon.ca", "amazon.de", "amazon.fr", "amazon.it"] = "amazon.com"
    country: str = Field(default="US", min_length=2, max_length=2)
    category: str | None = None
    max_price: float | None = Field(default=None, gt=0)
    currency: str = "USD"

class ResearchTaskResponse(BaseModel):
    task_id: str
    status: Literal["queued", "processing", "completed", "failed"]
    message: str
