from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.v1 import health, research

app = FastAPI(title="AYAM INTELLIGENCE API", version="0.1.0",
              description="Worldwide commerce intelligence API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)
app.include_router(health.router, prefix="/api/v1", tags=["health"])
app.include_router(research.router, prefix="/api/v1", tags=["research"])
