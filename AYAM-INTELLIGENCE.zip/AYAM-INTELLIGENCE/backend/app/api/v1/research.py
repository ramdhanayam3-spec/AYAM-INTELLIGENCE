from fastapi import APIRouter, HTTPException
from uuid import uuid4
from app.schemas.research import ProductResearchRequest, ResearchTaskResponse
from app.services.opportunity_scoring import score_opportunity
from app.services.profit_calculator import ProfitInput, calculate_profit

router = APIRouter()

@router.post("/products/research", response_model=ResearchTaskResponse, status_code=202)
async def create_product_research(payload: ProductResearchRequest):
    # TODO: enqueue a Celery orchestration task. Do not return fabricated provider data.
    task_id = str(uuid4())
    return ResearchTaskResponse(task_id=task_id, status="queued",
                                message="Research accepted. Configure providers and worker to execute live jobs.")

@router.post("/scoring/preview")
async def score_preview(payload: dict):
    try:
        total = score_opportunity(
            demand=float(payload["demand"]), profit=float(payload["profit"]),
            competition=float(payload["competition"]), keywords=float(payload["keywords"]),
            growth=float(payload["growth"]))
        return {"opportunity_score": total, "scale": "0-100"}
    except (KeyError, ValueError, TypeError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

@router.post("/profit-calculator")
async def profit_preview(payload: ProfitInput):
    return calculate_profit(payload)
