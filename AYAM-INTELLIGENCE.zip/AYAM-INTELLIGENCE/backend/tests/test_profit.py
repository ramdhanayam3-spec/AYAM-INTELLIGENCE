from app.services.profit_calculator import ProfitInput, calculate_profit

def test_profit_calculation():
    result = calculate_profit(ProfitInput(selling_price=100, product_cost=40, shipping_cost=5, marketplace_fee_pct=15, ad_cost_per_order=10))
    assert result["net_profit"] == 30
    assert result["profit_margin_pct"] == 30
