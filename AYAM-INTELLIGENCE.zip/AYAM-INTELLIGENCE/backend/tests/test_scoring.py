import pytest
from app.services.opportunity_scoring import score_opportunity

def test_weights_sum_to_100_score():
    assert score_opportunity(demand=100, profit=100, competition=100, keywords=100, growth=100) == 100

def test_reject_out_of_range():
    with pytest.raises(ValueError):
        score_opportunity(demand=101, profit=50, competition=50, keywords=50, growth=50)
